package org.automation.assignment2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class TS2_TC1 {
	public ChromeDriver driver;
	
	@Test(priority=1)
	public void Testcase1() throws Exception {
	System.setProperty("webdriver.chrome.driver","D:\\Java\\Selenium_Automation\\chromedriver.exe");
	 driver= new ChromeDriver();
	 driver.get("https://www.olay.com/");
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
	 driver.findElementByXPath("//a[contains(text(),'Register')]").click();
	 driver.findElementById("phdesktopbody_0_grs_account[emails][0][address]").sendKeys("AnuWEEN123@gmail.com");
	 driver.findElementById("phdesktopbody_0_grs_account[password][password]").sendKeys("Apple@123");
	 driver.findElementById("phdesktopbody_0_grs_account[password][confirm]").sendKeys("Apple@123");
	 Select date = new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][day]")));
	 date.selectByValue("09");
	 Select Month = new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][month]")));
	 Month.selectByValue("10");
	 Select Year = new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][year]")));
	 Year.selectByValue("1988");
	 JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement Element = driver.findElement(By.id("phdesktopbody_0_submit"));
		js.executeScript("arguments[0].scrollIntoView();", Element);
	     driver.findElementById("phdesktopbody_0_submit").click();
		Thread.sleep(10000);
	 driver.findElementById("phdesktopheader_0_phdesktopheadertop_2_LogOffLink").click();
	 driver.findElementByLinkText("Logout").click();
	 Thread.sleep(10000);
	 driver.findElementByXPath("//a[contains(text(),'Sign In')]").click();
	 driver.findElementById("phdesktopbody_0_username").sendKeys("AnuWE123@gmail.com");
	 driver.findElementById("phdesktopbody_0_password").sendKeys("Apple@123");
	 driver.findElementById("phdesktopbody_0_SIGN IN").click();
	 
	}
	@Test(priority=2)
	public void testcase2() throws Exception {
		//GERMAN REGISTRATION
		driver.get("https://www.olaz.de/de-de");
		driver.findElement(By.xpath("//a[contains(text(),'Registrieren')]")).click();
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_imgfemale']")).click();
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[firstname]']")).sendKeys("Ana");
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[lastname]']")).sendKeys("Mausami");
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_account[emails][0][address]']")).sendKeys("Ana@gmail.com");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_account[password][password]']")).sendKeys("Ast@123");
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_account[password][confirm]']")).sendKeys("Ast@123");
		Thread.sleep(1000);
		Select date2 = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_day]']")));
		date2.selectByValue("06");
		Thread.sleep(1000);
		Select month2 = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_month]']")));
		month2.selectByValue("05");
		Thread.sleep(1000);
		Select year2 = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_year]']")));
		year2.selectByValue("1995");
		Thread.sleep(1000);
		Select land = new Select(driver.findElement(By.xpath("//*[@data-key='addressCountry']")));
		land.selectByValue("DEU");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@data-key='addressStreet1']")).sendKeys("Addressline 1234");
		driver.findElement(By.xpath("//*[@data-key='addressPostalCode']")).sendKeys("201305");
		driver.findElement(By.xpath("//*[@data-key='addressCity']")).sendKeys("Zurich");
		driver.findElement(By.xpath("//*[@id='phdesktopbody_0_submit']")).click();
		Thread.sleep(2000);
		driver.close();
	}
}
