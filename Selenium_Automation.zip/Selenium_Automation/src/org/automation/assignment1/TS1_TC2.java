package org.automation.assignment1;

	import java.io.File;
	import java.util.List;
	import java.util.concurrent.TimeUnit;

	import org.apache.commons.io.FileUtils;
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.OutputType;
	import org.openqa.selenium.TakesScreenshot;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.Select;
	import org.testng.annotations.Test;


	public class TS1_TC2 {
		public FirefoxDriver driver;
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		
		@Test(priority=1)
		public  void testcas1() {
		System.setProperty("webdriver.gecko.driver","D:\\Maven\\Wipro\\Selenium_Automation\\geckodriver.exe");
		 driver= new FirefoxDriver();
		 driver.get("https://demoqa.com/elements");
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		 WebElement txt=driver.findElementByXPath("//span[contains(.,'Text Box')]");
		 driver.findElementByXPath("//span[contains(.,'Text Box')]").click();
		 System.out.println(txt.getText());
		 WebElement txt1=driver.findElementByXPath("//span[contains(.,'Check Box')]");
		 driver.findElementByXPath("//span[contains(.,'Check Box')]").click();
		 System.out.println(txt1.getText());
		 WebElement txt2=driver.findElementByXPath("//span[contains(.,'Radio Button')]");
		 driver.findElementByXPath("//span[contains(.,'Radio Button')]").click();
		 System.out.println(txt2.getText());
		 WebElement txt3=driver.findElementByXPath("//span[contains(.,'Web Tables')]");
		 driver.findElementByXPath("//span[contains(.,'Web Tables')]").click();
		 System.out.println(txt3.getText());
		 WebElement txt4=driver.findElementByXPath("//span[contains(.,'Buttons')]");
		 driver.findElementByXPath("//span[contains(.,'Buttons')]").click();
		 System.out.println(txt4.getText());
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 WebElement Elmnt = driver.findElement(By.xpath("//span[contains(.,'Links')]"));
		  js.executeScript("arguments[0].scrollIntoView();", Elmnt);
		  WebElement txt5=driver.findElementByXPath("//span[contains(.,'Links')]");
		  driver.findElementByXPath("//span[contains(.,'Links')]").click();
		  System.out.println(txt5.getText());
		 WebElement Elmnt1 = driver.findElement(By.xpath("//span[contains(.,'Upload and Download')]"));
		  js.executeScript("arguments[0].scrollIntoView();", Elmnt1);
		  WebElement txt6=driver.findElementByXPath("//span[contains(.,'Upload and Download')]");
		  driver.findElementByXPath("//span[contains(.,'Upload and Download')]").click();
		  System.out.println(txt6.getText());
		  WebElement Elmnt2 = driver.findElement(By.xpath("//span[contains(.,'Dynamic Properties')]"));
		  js.executeScript("arguments[0].scrollIntoView();", Elmnt2);
		  WebElement txt7=driver.findElementByXPath("//span[contains(.,'Dynamic Properties')]");
		  driver.findElementByXPath("//span[contains(.,'Dynamic Properties')]").click();
		  System.out.println(txt7.getText());
		}
		@Test(priority=2)
		public  void testcas2() {
			driver.findElementByXPath("//span[contains(.,'Text Box')]").click();
			driver.findElementById("userName").sendKeys("Anuradha Yadav");
			driver.findElementById("userEmail").sendKeys("Anuradha.Yadav@gmail.com");
			driver.findElementById("currentAddress").sendKeys("Royal Park,Noida");
			driver.findElementById("permanentAddress").sendKeys("Supertech,Gorakhpur");
			driver.findElementById("submit").click();
			 driver.quit();
		}
		
		@Test(priority=3)
		public  void testcas3() throws Exception {
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement Element = driver.findElement(By.xpath("//span[contains(.,'Links')]"));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			driver.findElementByXPath("//span[contains(.,'Links')]").click();
	        driver.findElementByLinkText("Home").click();
	        takeSnapShot( driver,"./Screenshots/Screen.png");
	        System.out.println("Title of page is:"+driver.getTitle());
	        Thread.sleep(100000);
	        driver.quit();
	        
	        driver= new FirefoxDriver();
	        driver.get("https://demoqa.com/elements");
	       // driver.findElementByCssSelector(".card:nth-child(1) path").click();
	        WebElement Element1 = driver.findElement(By.xpath("//span[contains(.,'Links')]"));
			js.executeScript("arguments[0].scrollIntoView();", Element1);
			driver.findElementByXPath("//span[contains(.,'Links')]").click();
	        driver.findElementByPartialLinkText("Home").click();
	    	takeSnapShot( driver,"./Screenshots/Screen1.png");
	        System.out.println("Title of page is:"+driver.getTitle());
	        Thread.sleep(10000);
	        driver.quit();
	        
		}

		public void takeSnapShot(WebDriver driver,String fileWithPath) throws Exception{

	        //Convert web driver object to TakeScreenshot

	        TakesScreenshot scrShot =((TakesScreenshot)driver);

	        //Call getScreenshotAs method to create image file

	                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

	            //Move image file to new destination

	                File DestFile=new File(fileWithPath);

	                //Copy file at destination

	                FileUtils.copyFile(SrcFile, DestFile);

	    }
		@Test(priority=4)
		public  void testcas4() throws Exception {
			driver= new FirefoxDriver();
	        driver.get("https://demoqa.com/droppable");
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
	        Actions builder = new Actions(driver);
	        WebElement from = driver.findElement(By.id("draggable"));
	        highLightElement(driver,from);
	        WebElement to = driver.findElement(By.id("droppable")); 
	        highLightElement(driver,to);
	        //Perform drag and drop
	        builder.dragAndDrop(from, to).release().build().perform();
	       
	        //verify text changed in to 'Drop here' box 
	        String textTo = to.getText();
	        
	        if(textTo.equals("Dropped!")) {
	        System.out.println("PASS: Source is dropped to target as expected");
	        }else {
	        System.out.println("FAIL: Source couldn't be dropped to target as expected");
	        }
	        
	        driver.quit();
	        
		}
		public static void highLightElement(WebDriver driver, WebElement element)
		{
		JavascriptExecutor js=(JavascriptExecutor)driver; 
		 
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
		 
		try 
		{
		Thread.sleep(1000);
		} 
		catch (InterruptedException e) {
		 
		System.out.println(e.getMessage());
		} 
		 
		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element); 
		 
		}
		@Test(priority=5)
		public void datepicke() throws Exception {
			driver= new FirefoxDriver();
	        driver.get("https://demoqa.com/date-picker");
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);	
		driver.findElementById("datePickerMonthYearInput").click();
		driver.findElementByXPath("//div[@id='datePickerMonthYear']/div[2]/div[2]/div/div/div[2]/div/div[2]/div/select").click();
		Select month = new Select(driver.findElement(By.className("react-datepicker__month-select")));
		month.selectByValue("9");
		Select year = new Select(driver.findElement(By.className("react-datepicker__year-select")));
		year.selectByValue("1988");
		
		driver.findElementByXPath("//div[@id='datePickerMonthYear']/div[2]/div[2]/div/div/div[2]/div[2]/div[4]/div[5]").click();
		WebElement text=driver.findElementById("datePickerMonthYearInput");
		System.out.println("The selected date is" +text);
		driver.quit();
		
		/*List<WebElement> days = driver.findElementsByClassName("react-datepicker__month");

		for (WebElement d:days)
		{ 
		System.out.println(d.getText());
		if(d.getText().equals("10"))
		{
		d.click();
		Thread.sleep(10000);
		}
	}*/
		}

		@Test(priority=6)
		public  void testcas6() throws Exception {
			driver= new FirefoxDriver();
	        driver.get("https://demoqa.com/select-menu");
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
	        driver.findElement(By.xpath("//div[@id='withOptGroup']/div/div")).click();
	        driver.findElement(By.xpath("//div[@id='react-select-2-option-2']")).click();
	        Thread.sleep(1000);
	    	driver.findElement(By.xpath("//div[@id='selectOne']/div/div")).click();
	    	driver.findElementByXPath("//div[@id='react-select-3-option-0-2']").click();
	    	driver.findElementByXPath("//select[@id='oldSelectMenu']").click();
	    	Select color = new Select(driver.findElement(By.id("oldSelectMenu")));
	    	color.selectByIndex(9);
	    	driver.findElementByXPath("//select[@id='oldSelectMenu']").click();
	    	Thread.sleep(1000);
	    	driver.findElement(By.xpath("//div[@id='selectMenuContainer']/div[7]/div/div/div/div")).click();
	    	driver.findElement(By.xpath("//div[@id='react-select-4-option-0']")).click();
	    	driver.findElement(By.xpath("//div[@id='react-select-4-option-1']")).click();


	 Select oSelect = new Select(driver.findElement(By.id("cars")));
	 oSelect.selectByIndex(1);
	 oSelect.selectByIndex(2);
	 driver.quit();
	 
		}
		}


